// app/not-found.js
export default function NotFound() {
    return (
    <div className="d-flex justify-content-center align-items-center vh-90
    text-danger display-1">
    !صفحه مورد نظر یافت نشد
    </div>
    );
    }